from setuptools import setup, find_packages

setup(
    name="le_custom",
    version="0.0.1",
    description="Custom Label Encoder Module",
    author="Mansoor Baig",
    packages=find_packages(),
    license="MIT"
)